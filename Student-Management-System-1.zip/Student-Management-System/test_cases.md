# Test Cases and Expected Output

Use the demo login:
- User ID: `admin`
- Password: `admin123`

## Test 1: Successful login
**Input:** admin / admin123  
**Expected:** `Login successful. Welcome!`

## Test 2: Incorrect login
**Input:** Enter an incorrect username or password three times.  
**Expected:** The program displays an incorrect-login message and exits after three attempts.

## Test 3: Register a student
**Input:**
- Menu choice: 1
- Student ID: 101
- Name: Ananya Das
- Fees paid: 5000

**Expected:** `Student registered successfully.` and a message that course allocation is now available.

## Test 4: Allocate a course
**Input:**
- Menu choice: 4
- Student ID: 101
- Course: DS

**Expected:** `Course allocated successfully.`

## Test 5: Update result
**Input:**
- Menu choice: 5
- Student ID: 101
- Result: Excellent

**Expected:** `Student result updated successfully.`

## Test 6: View student records
**Input:** Menu choice 2  
**Expected record details:**
- ID: 101
- Name: Ananya Das
- Fees: 5000.00
- Course: DS
- Result: Excellent

## Test 7: Fees not paid
**Input:** Register another student with ID 102 and fees 0, then select course allocation for ID 102.  
**Expected:** `Fees have not been paid. Course cannot be allocated.`

## Test 8: Invalid course
**Input:** Enter a course other than DS, AI, ML, or Web.  
**Expected:** `Invalid course. Please choose DS, AI, ML, or Web.`

## Test 9: Duplicate student ID
**Input:** Try to register ID 101 again.  
**Expected:** `A student with this ID already exists.`

## Test 10: Persistent storage
**Steps:** Register a student, exit the program, and run it again. Select View All Students.  
**Expected:** The previously saved student record is still displayed.
