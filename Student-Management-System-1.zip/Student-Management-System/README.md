# Student Management System (C)

## Project overview
A menu-driven C application for a small education institute. It stores student ID, name, fees, course allocation, and result.

## Features
- Login authentication (three attempts)
- Student registration
- View all students
- Search by student ID
- Course allocation: DS, AI, ML, Web
- Course allocation is allowed only when fees paid are greater than zero
- Result update: Excellent, Good, Fail
- Persistent storage using a binary file (`students.dat`)

## Demo login
- User ID: `admin`
- Password: `admin123`

This is a classroom demonstration login. For a real application, passwords should be securely hashed and not stored as plain text.

## Requirements
- GCC compiler or another C compiler

## Compile and run

### Windows (MinGW)
```bash
gcc main.c -o student_management.exe
student_management.exe
```

### Linux / macOS
```bash
gcc main.c -o student_management
./student_management
```

The program creates `students.dat` in the same folder when the first student is registered. Keep this file to retain records between runs.

## Data structure
The program uses a `struct Student` containing:
- `id`
- `name`
- `fees`
- `course`
- `result`

## Test cases
See [test_cases.md](test_cases.md).

## Note
Use the exact result spelling `Excellent`, `Good`, or `Fail`, and course spelling `DS`, `AI`, `ML`, or `Web`.
