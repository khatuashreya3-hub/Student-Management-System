/*
 * Student Management System
 * Language: C
 * Concepts: structures, functions, menu-driven programming, file handling
 *
 * Demo login:
 * Username: admin
 * Password: admin123
 *
 * Data is stored in students.dat, so records remain after the program closes.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DATA_FILE "students.dat"
#define TEMP_FILE "students.tmp"
#define NAME_LEN 60
#define COURSE_LEN 10
#define RESULT_LEN 20

typedef struct {
    int id;
    char name[NAME_LEN];
    float fees;
    char course[COURSE_LEN];
    char result[RESULT_LEN];
} Student;

void removeNewline(char *s) {
    s[strcspn(s, "\n")] = '\0';
}

void readLine(const char *prompt, char *buffer, size_t size) {
    printf("%s", prompt);
    if (fgets(buffer, (int)size, stdin) != NULL) {
        removeNewline(buffer);
    } else {
        buffer[0] = '\0';
    }
}

int readInt(const char *prompt) {
    char line[100];
    int value;
    char extra;
    while (1) {
        readLine(prompt, line, sizeof(line));
        if (sscanf(line, "%d %c", &value, &extra) == 1) return value;
        printf("Invalid input. Please enter a whole number.\n");
    }
}

float readFloat(const char *prompt) {
    char line[100];
    float value;
    char extra;
    while (1) {
        readLine(prompt, line, sizeof(line));
        if (sscanf(line, "%f %c", &value, &extra) == 1 && value >= 0)
            return value;
        printf("Invalid amount. Please enter a non-negative number.\n");
    }
}

int login(void) {
    char username[40], password[40];
    int attempts;

    printf("====================================\n");
    printf("       STUDENT MANAGEMENT SYSTEM\n");
    printf("====================================\n");

    for (attempts = 1; attempts <= 3; attempts++) {
        readLine("User ID: ", username, sizeof(username));
        readLine("Password: ", password, sizeof(password));

        if (strcmp(username, "admin") == 0 &&
            strcmp(password, "admin123") == 0) {
            printf("\nLogin successful. Welcome!\n");
            return 1;
        }
        printf("Incorrect User ID or Password. Attempts left: %d\n",
               3 - attempts);
    }
    printf("Maximum login attempts reached.\n");
    return 0;
}

int studentExists(int id) {
    FILE *fp = fopen(DATA_FILE, "rb");
    Student s;

    if (fp == NULL) return 0;
    while (fread(&s, sizeof(Student), 1, fp) == 1) {
        if (s.id == id) {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

void addStudent(void) {
    Student s;
    FILE *fp;

    printf("\n--- Student Registration ---\n");
    s.id = readInt("Enter student ID: ");
    if (studentExists(s.id)) {
        printf("A student with this ID already exists.\n");
        return;
    }

    readLine("Enter student name: ", s.name, sizeof(s.name));
    if (strlen(s.name) == 0) {
        printf("Name cannot be empty.\n");
        return;
    }

    s.fees = readFloat("Enter fees paid (0 if not paid): ");
    strcpy(s.course, "Not set");
    strcpy(s.result, "Pending");

    fp = fopen(DATA_FILE, "ab");
    if (fp == NULL) {
        printf("Error opening data file.\n");
        return;
    }
    fwrite(&s, sizeof(Student), 1, fp);
    fclose(fp);

    printf("Student registered successfully.\n");
    if (s.fees > 0)
        printf("Fees recorded. The student can now be allocated a course.\n");
    else
        printf("Course allocation is unavailable until fees are paid.\n");
}

void printStudent(const Student *s) {
    printf("\nID      : %d\n", s->id);
    printf("Name    : %s\n", s->name);
    printf("Fees    : %.2f\n", s->fees);
    printf("Course  : %s\n", s->course);
    printf("Result  : %s\n", s->result);
}

void viewStudents(void) {
    FILE *fp = fopen(DATA_FILE, "rb");
    Student s;
    int count = 0;

    printf("\n--- All Registered Students ---\n");
    if (fp == NULL) {
        printf("No student records found yet.\n");
        return;
    }

    while (fread(&s, sizeof(Student), 1, fp) == 1) {
        printStudent(&s);
        count++;
    }
    fclose(fp);

    if (count == 0) printf("No student records found yet.\n");
    else printf("\nTotal students: %d\n", count);
}

void searchStudent(void) {
    int id, found = 0;
    Student s;
    FILE *fp = fopen(DATA_FILE, "rb");

    printf("\n--- Search Student ---\n");
    id = readInt("Enter student ID to search: ");

    if (fp == NULL) {
        printf("No student records found.\n");
        return;
    }

    while (fread(&s, sizeof(Student), 1, fp) == 1) {
        if (s.id == id) {
            printStudent(&s);
            found = 1;
            break;
        }
    }
    fclose(fp);

    if (!found) printf("Student ID not found.\n");
}

void allocateCourse(void) {
    int id, found = 0, updated = 0;
    char course[COURSE_LEN];
    Student s;
    FILE *in, *out;

    printf("\n--- Course Allocation ---\n");
    id = readInt("Enter student ID: ");

    in = fopen(DATA_FILE, "rb");
    if (in == NULL) {
        printf("No student records found.\n");
        return;
    }
    out = fopen(TEMP_FILE, "wb");
    if (out == NULL) {
        fclose(in);
        printf("Could not create temporary file.\n");
        return;
    }

    while (fread(&s, sizeof(Student), 1, in) == 1) {
        if (s.id == id) {
            found = 1;
            if (s.fees <= 0) {
                printf("Fees have not been paid. Course cannot be allocated.\n");
            } else {
                printf("Available courses: DS, AI, ML, Web\n");
                readLine("Enter course: ", course, sizeof(course));

                if (strcmp(course, "DS") == 0 ||
                    strcmp(course, "AI") == 0 ||
                    strcmp(course, "ML") == 0 ||
                    strcmp(course, "Web") == 0) {
                    strcpy(s.course, course);
                    strcpy(s.result, "Pending");
                    updated = 1;
                } else {
                    printf("Invalid course. Please choose DS, AI, ML, or Web.\n");
                }
            }
        }
        fwrite(&s, sizeof(Student), 1, out);
    }

    fclose(in);
    fclose(out);

    remove(DATA_FILE);
    rename(TEMP_FILE, DATA_FILE);

    if (!found) printf("Student ID not found.\n");
    else if (updated) printf("Course allocated successfully.\n");
}

void updateResult(void) {
    int id, found = 0, updated = 0;
    char result[RESULT_LEN];
    Student s;
    FILE *in, *out;

    printf("\n--- Result Management ---\n");
    id = readInt("Enter student ID: ");

    in = fopen(DATA_FILE, "rb");
    if (in == NULL) {
        printf("No student records found.\n");
        return;
    }
    out = fopen(TEMP_FILE, "wb");
    if (out == NULL) {
        fclose(in);
        printf("Could not create temporary file.\n");
        return;
    }

    while (fread(&s, sizeof(Student), 1, in) == 1) {
        if (s.id == id) {
            found = 1;
            if (strcmp(s.course, "Not set") == 0) {
                printf("Allocate a course before entering the result.\n");
            } else {
                printf("Result options: Excellent, Good, Fail\n");
                readLine("Enter result: ", result, sizeof(result));

                if (strcmp(result, "Excellent") == 0 ||
                    strcmp(result, "Good") == 0 ||
                    strcmp(result, "Fail") == 0) {
                    strcpy(s.result, result);
                    updated = 1;
                } else {
                    printf("Invalid result. Use Excellent, Good, or Fail.\n");
                }
            }
        }
        fwrite(&s, sizeof(Student), 1, out);
    }

    fclose(in);
    fclose(out);

    remove(DATA_FILE);
    rename(TEMP_FILE, DATA_FILE);

    if (!found) printf("Student ID not found.\n");
    else if (updated) printf("Student result updated successfully.\n");
}

void showMenu(void) {
    printf("\n========== MAIN MENU ==========\n");
    printf("1. Register Student\n");
    printf("2. View All Students\n");
    printf("3. Search Student\n");
    printf("4. Allocate Course\n");
    printf("5. Update Student Result\n");
    printf("6. Exit\n");
    printf("===============================\n");
}

int main(void) {
    int choice;

    if (!login()) return 0;

    do {
        showMenu();
        choice = readInt("Enter your choice: ");

        switch (choice) {
            case 1: addStudent(); break;
            case 2: viewStudents(); break;
            case 3: searchStudent(); break;
            case 4: allocateCourse(); break;
            case 5: updateResult(); break;
            case 6: printf("Thank you for using the system.\n"); break;
            default: printf("Invalid choice. Please select 1 to 6.\n");
        }
    } while (choice != 6);

    return 0;
}
